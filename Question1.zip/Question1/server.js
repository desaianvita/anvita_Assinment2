const express = require('express');
const mongoose = require('mongoose');
const multer = require('multer');
const bodyParser = require('body-parser');
const path = require('path');
const dotenv = require('dotenv');

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const userSchema = new mongoose.Schema({
  name: String,
  email: String,
  files: [String],
});

const User = mongoose.model('User', userSchema);

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.set('view engine', 'ejs');

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'public/uploads/');
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname);
  },
});

const upload = multer({ storage: storage });

app.get('/', (req, res) => {
    res.send('Welcome to the User Registration App! Go to /register to register.');
});


app.get('/register', (req, res) => {
  res.render('register');
});

app.post('/register', upload.array('files', 10), async (req, res) => {
  const { name, email } = req.body;
  const fileNames = req.files.map(file => file.filename);

  const user = new User({ name, email, files: fileNames });
  await user.save();
  res.redirect('/files');
});

app.get('/files', async (req, res) => {
  const users = await User.find();
  res.render('files', { users });
});

app.get('/download/:filename', (req, res) => {
  const file = path.join(__dirname, 'public/uploads', req.params.filename);
  res.download(file);
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
