const express = require('express');
const router = express.Router();
const Student = require('../models/Student');

router.get('/', async (req, res) => {
    const students = await Student.find();
    res.render('students', { students });
});

router.post('/add', async (req, res) => {
    const { name, email, age, password } = req.body;
    const newStudent = new Student({ name, email, age, password });
    await newStudent.save();
    res.redirect('/students');
});

router.get('/edit/:id', async (req, res) => {
    const student = await Student.findById(req.params.id);
    res.render('editStudent', { student });
});

router.post('/update/:id', async (req, res) => {
    const { name, email, age, password } = req.body;
    await Student.findByIdAndUpdate(req.params.id, { name, email, age, password });
    res.redirect('/students');
});

router.post('/delete/:id', async (req, res) => {
    await Student.findByIdAndDelete(req.params.id);
    res.redirect('/students');
});

module.exports = router;
