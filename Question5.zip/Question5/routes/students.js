const express = require('express');
const Student = require('../models/Student');
const router = express.Router();
const authenticateToken = require('../middleware/authenticateToken');

router.get('/', authenticateToken, async (req, res) => {
    const students = await Student.find();
    res.json(students);
});

router.post('/', authenticateToken, async (req, res) => {
    const { name, email, age, password } = req.body;
    const newStudent = new Student({ name, email, age, password });
    await newStudent.save();
    res.status(201).json(newStudent);
});

router.put('/:id', authenticateToken, async (req, res) => {
    const { name, email, age, password } = req.body;
    await Student.findByIdAndUpdate(req.params.id, { name, email, age, password });
    res.status(200).json({ message: 'Student updated successfully' });
});

router.delete('/:id', authenticateToken, async (req, res) => {
    await Student.findByIdAndDelete(req.params.id);
    res.status(200).json({ message: 'Student deleted successfully' });
});

module.exports = router;
