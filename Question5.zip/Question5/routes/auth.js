const express = require('express');
const jwt = require('jsonwebtoken');
const Student = require('../models/Student'); 
const router = express.Router();
const path=require('path')

router.post('/register', async (req, res) => {
    const { name, email, age, password } = req.body;

    const newStudent = new Student({ name, email, age, password });
    await newStudent.save();
    res.status(201).json({ message: 'Student registered successfully' });
});

router.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, '../public/index.html')); 
});

router.post('/login', async (req, res) => {
    const { email, password } = req.body;
    const student = await Student.findOne({ email });

    if (student && student.password === password) {
        const token = jwt.sign({ id: student._id }, process.env.JWT_SECRET);
        res.json({ token });
    } else {
        res.status(401).json({ message: 'Invalid credentials' });
    }
});

module.exports = router;
